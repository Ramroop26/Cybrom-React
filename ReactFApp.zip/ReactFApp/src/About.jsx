const About=()=>{

    return(

        <h1>Our About page</h1>
    )
}

export default About;