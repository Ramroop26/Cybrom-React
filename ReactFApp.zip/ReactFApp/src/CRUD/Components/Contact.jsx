const Contact=()=>{
    return(
        <>
        <h1>Welcome to Contact Page</h1>
        </>
    )

}
export default Contact;