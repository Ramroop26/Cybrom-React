import "./STYLE/Home.css";
const Home=()=>{
    return(
        <>
        
        <marquee behavior="" direction="left"><h1 style={{ color:"red", }}>Welcome To Home Page</h1></marquee>
         <marquee behavior="" direction="left"><h1 style={{ color:"blue", }}>Welcome To Home Page</h1></marquee>
          <marquee behavior="" direction="left"><h1 style={{ color:"green", }}>Welcome To Home Page</h1></marquee>
           <marquee behavior="" direction="left"><h1 style={{ color:"yellow", }}>Welcome To Home Page</h1></marquee>

        </>
    )

}
export default Home;