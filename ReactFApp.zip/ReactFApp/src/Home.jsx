const Home=()=>{

    return(
        <>
        <h1 style={{color:"red", fontFamily:"-moz-initial", textDecoration:"underline"}}>Welcome to Home Page</h1>
        <h1 style={{color:"blue", fontFamily:"verdana"}}>Welcome to Home Page</h1>
        </>
    )
}

export default Home;